from example_package_rookie_007 import example

print(example.add_one(3))